geopnr
======

Présentation utilisée lors du geopnr.
la licence d'utilisation de ce document est CC-BY

Plusieurs ressources utilisées sont issues de "the noun project": 
http://thenounproject.com/

* Social Network designed by Gustav Salomonsson
* Network designed by Brennan Novak
* Speaker designed by Harold Kim


Les analyses cartographiques sont issues des produits de l'IGN et le projet OpenStreetMap.
ces données ont été utilisées dans le cadre de l'exploitation du RGE. 




